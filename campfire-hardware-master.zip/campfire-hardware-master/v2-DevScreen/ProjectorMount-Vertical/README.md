ProjectorMount-Vertical
======
This Assembly is used to mount a projector with the lens pointed upwards. The assembly bolts to vertical strut channel members spaced 18 degrees apart around the outside of the radiused strut channel.

![ProjectorMount-Vertical](preview.png?raw=true)

    BOM

      Part Name                               Qty.       Notes
        ProjectorMount-Vertical-Base           1          Laser Cut Steel
        ProjectorMount-Vertical-Cap            2          Laser Cut Steel
        ProjectorMount-Vertical-MountFace      2          Laser Cut Steel
        ProjectorMount-Vertical-OutsideBrace   2          Laser Cut Steel
        ProjectorMount-Vertical-Side           2          Laser Cut Steel

    Mounting

      Part                               Qty.               Link
        Bolt                              4                  
        Strut channel nut                 4                  
        Washer                            4