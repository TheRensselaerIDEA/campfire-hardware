DeskBracket
======
This assembly supports the desk surface. At least 5 are required, one on each primary strut channel leg, but more can be used as needed (bolted onto secondary vertical struts)

![DeskBracket](preview.png?raw=true)

    BOM

      Part Name                    Qty.       Notes
        DeskBracket-Side           2          Laser Cut Steel
        DeskBracket-Top            1          Laser Cut Steel
        DeskBracket-LowerBack      1          Laser Cut Steel
        DeskBracket-UpperBack      1          Laser Cut Steel

    Mounting

      Part                               Qty.               Link
        Bolt                              2                  
        Strut channel nut                 4                  
        Washer                            4