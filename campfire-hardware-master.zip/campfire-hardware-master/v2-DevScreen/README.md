DevScreen-v0.03
======
This version is designed for maximum utility, with tons of mounting options for projectors, optics, sensors, screen materials, desk surfaces (or lack thereof) and more. It's construction is a mix of standard strut channel and custom laser cut steel parts designed for modularity and reconfigurability.

![DevScreen-v0.03](preview.png?raw=true)
