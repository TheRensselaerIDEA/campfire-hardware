FloorBracket
======
This assembly serves not only as a spacer between the bottom of the legs and the bottom of the first radiused strut channel, but also as a support to hold up the floor material. Five of these supports are required, and one bolts to the inside of each primary strut channel leg.

![FloorBracket](preview.png?raw=true)

    BOM

      Part Name                    Qty.       Notes
        FloorBracket-MountFace      2          Laser Cut Steel
        FloorBracket-Side           2          Laser Cut Steel

    Mounting

      Part                               Qty.               Link
        Bolt                              2                  
        Strut channel nut                 4                  
        Washer                            4