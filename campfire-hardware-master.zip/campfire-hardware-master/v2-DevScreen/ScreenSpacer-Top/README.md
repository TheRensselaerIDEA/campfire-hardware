ScreenSpacer-Top
======
This assembly is a spacer which goes between the radiused strut channel at the top of the screen and the radiused strut channel on the underside of the desk surface. 5 such spacers are required, and one is bolted to the inside of each primary strut channel leg.

![ScreenSpacer-Top](preview.png?raw=true)

    BOM

      Part Name                          Qty.               Notes
        ScreenSpacer-Top-Back             1                  Laser Cut Steel
        ScreenSpacer-Top-Rib              2                  Laser Cut Steel

    Mounting

      Part                               Qty.               Link
        Bolt                              2                  
        Nut                               2                  
        Washer                            4