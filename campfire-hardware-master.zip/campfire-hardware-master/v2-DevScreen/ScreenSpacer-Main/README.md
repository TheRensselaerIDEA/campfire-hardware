ScreenSpacer-Main
======
This assembly is a spacer which goes between the radiused strut channel at the top and bottom of the screen. 5 such spacers are required, and one is bolted to the inside of each primary strut channel leg.

![ScreenSpacer-Main](preview.png?raw=true)

    BOM

      Part Name                          Qty.               Notes
        ScreenSpacer-Main-Back             1                  Laser Cut Steel
        ScreenSpacer-Main-Rib              2                  Laser Cut Steel

    Mounting

      Part                               Qty.               Link
        Bolt                              2                  
        Nut                               2                  
        Washer                            4