ProjectorMount-Horizontal
======
This Assembly is used to mount a projector with the lens pointed inwards. The assembly bolts to vertical strut channel members spaced 18 degrees apart around the outside of the radiused strut channel.

![ProjectorMount-Horizontal](preview.png?raw=true)

    BOM

      Part Name                               Qty.       Notes
        ProjectorMount-Horizontal-Base           1          Laser Cut Steel
        ProjectorMount-Horizontal-Front          1          Laser Cut Steel
        ProjectorMount-Horizontal-MountFace      2          Laser Cut Steel
        ProjectorMount-Horizontal-RearBrace      2          Laser Cut Steel
        ProjectorMount-Horizontal-Side           2          Laser Cut Steel

    Mounting

      Part                               Qty.               Link
        Bolt                              4                  
        Strut channel nut                 4                  
        Washer                            4